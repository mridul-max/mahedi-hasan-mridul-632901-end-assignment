# mahedi-hasan-mridul-632901-end-assignment
# User Account Information

This document provides information about the user accounts in the application. The application has three predefined user accounts for demonstration purposes. Below, you'll find the details for each user:

## Salesperson
- **Username**: wim
- **Password**: wim


## Manager (1)
- **Username**: def
- **Password**: def

## Manager (2)
- **Username**: lll
- **Password**: lll

Please note that these are predefined user accounts for demonstration purposes, and you can adjust them as needed in the application.

