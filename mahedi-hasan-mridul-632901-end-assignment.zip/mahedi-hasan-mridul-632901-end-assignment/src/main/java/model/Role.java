package model;

import java.io.Serializable;

public enum Role implements Serializable {
    Manager,
    SALESPERSON
}

